/**
 * Copyright (c) 2004-2014 Alex Trin
 * email:alextrin@rambler.ru
 *
 * Font for games XML/XML2/MUA
 */

#include <stdio.h>
#include "xmlbexporter.h"
#include "../fontconfig.h"
#include "../layoutdata.h"

#include <QString>

XMLBExporter::XMLBExporter(QObject *parent) :
    AbstractExporter(parent)
{
    setExtension("xml");
}

bool XMLBExporter::Export(QByteArray& out) {
    int PageWidth = texWidth();
    int PageHeight = texHeight();
  
    QString res = "XMLB FONT_TABLE {\n";
    res+=QString("ascender = ")+QString().number(metrics().ascender)+QString(" ;\n");
    res+=QString("descender = ")+QString().number(metrics().descender)+QString(" ;\n");
    res+=QString("height = ")+QString().number(metrics().height)+QString(" ;\n");
    res+=QString("pointsize = ")+QString().number(fontConfig()->size())+QString(" ;\n");
	
   foreach (const Symbol& c , symbols()) {
        float  xs = 1.f / PageWidth, ys = 1.f / PageHeight;
        int Arr[] = {1025, 1105, 1040, 1041, 1042, 1043, 1044, 1045, 1046, 1047, 1048, 1049, 1050, 1051, 1052, 1053, 1054, 1055, 1056, 1057, 1058, 1059, 1060, 1061, 1062, 1063, 1064, 1065, 1066, 1067, 1068, 1069, 1070, 1071, 1072, 1073, 1074, 1075, 1076, 1077, 1078, 1079, 1080, 1081, 1082, 1083, 1084, 1085, 1086, 1087, 1088, 1089, 1090, 1091, 1092, 1093, 1094, 1095, 1096, 1097, 1098, 1099, 1100, 1101, 1102, 1103};
  	int Arr2[] = {168, 184, 192, 193, 194, 195, 196, 197, 198, 199, 200, 201, 202, 203, 204, 205, 206, 207, 208, 209, 210, 211, 212, 213, 214, 215, 216, 217, 218, 219, 220, 221, 222, 223, 224, 225, 226, 227, 228, 229, 230, 231, 232, 233, 234, 235, 236, 237, 238, 239, 240, 241, 242, 243, 244, 245, 246, 247, 248, 249, 250, 251, 252, 253, 254, 255};
	QString gnum;
	
	for (int i=0;i<66;++i)
	{
    		if (Arr[i] == c.id)
    		{
        	gnum = QString().number(Arr2[i]);
        	break;
    		}
	}
	if (gnum.isEmpty())
    	gnum = QString().number(c.id);
	
        QString charDef="glyph {\n";
	charDef+=QString("   baseline = ")+QString().number(c.offsetY)+QString(" ;\n");
	charDef+=QString("   height = ")+QString().number(c.placeH)+QString(" ;\n");
        charDef+=QString("   horizadvance = ")+QString().number(c.advance)+QString(" ;\n");
	charDef+=QString("   horizoffset = ")+QString().number(c.offsetX)+QString(" ;\n");
        charDef+=QString("   num = ")+QString(gnum)+QString(" ;\n");
        charDef+=QString("   s = ")+QString().number(c.placeX * xs)+QString(" ;\n");
	charDef+=QString("   s2 = ")+QString().number((c.placeX + c.placeW) * xs)+QString(" ;\n");
        charDef+=QString("   t = ")+QString().number(c.placeY * ys)+QString(" ;\n");
	charDef+=QString("   t2 = ")+QString().number((c.placeY + c.placeH) * ys)+QString(" ;\n");
        charDef+=QString("   width = ")+QString().number(c.placeW)+QString(" ;\n");
        res+=QString("   ")+charDef+QString("   }\n\n");
	
    }

    res+=QString("}\n");
    out = res.toUtf8();
    return true;
}


AbstractExporter* XMLBExporterFactoryFunc (QObject* parent) {
    return new XMLBExporter(parent);
}

