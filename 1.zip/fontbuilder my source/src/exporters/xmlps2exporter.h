/**
 * Copyright (c) 2004-2014 Alex Trin
 * email:alextrin@rambler.ru
 *
 * Font file for game XML PS2 
 */

#ifndef XMLPS2Exporter_H
#define XMLPS2Exporter_H

#include "../abstractexporter.h"

class XMLPS2Exporter : public AbstractExporter
{
Q_OBJECT
public:
    explicit XMLPS2Exporter(QObject *parent = 0);
protected:
    virtual bool Export(QByteArray& out);
signals:

public slots:

};

#endif // XMLPS2Exporter_H
