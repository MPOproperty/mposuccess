/**
 * Copyright (c) 2004-2014 Alex Trin
 * email:alextrin@rambler.ru
 *
 * Font for games XML/XML2/MUA
 */

#ifndef XMLBExporter_H
#define XMLBExporter_H

#include "../abstractexporter.h"

class XMLBExporter : public AbstractExporter
{
Q_OBJECT
public:
    explicit XMLBExporter(QObject *parent = 0);
protected:
    virtual bool Export(QByteArray& out);
signals:

public slots:

};

#endif // XMLBExporter_H
