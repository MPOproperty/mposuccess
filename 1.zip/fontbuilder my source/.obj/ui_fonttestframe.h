/********************************************************************************
** Form generated from reading UI file 'fonttestframe.ui'
**
** Created by: Qt User Interface Compiler version 4.8.6
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_FONTTESTFRAME_H
#define UI_FONTTESTFRAME_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QCheckBox>
#include <QtGui/QGridLayout>
#include <QtGui/QGroupBox>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QPlainTextEdit>
#include <QtGui/QRadioButton>
#include <QtGui/QScrollArea>
#include <QtGui/QSpacerItem>
#include <QtGui/QVBoxLayout>
#include <QtGui/QWidget>
#include "colorbutton.h"
#include "fonttestwidget.h"

QT_BEGIN_NAMESPACE

class Ui_FontTestFrame
{
public:
    QVBoxLayout *verticalLayout_2;
    QScrollArea *scrollArea;
    QWidget *scrollAreaWidgetContents;
    QGridLayout *gridLayout;
    FontTestWidget *drawWidget;
    QSpacerItem *verticalSpacer;
    QSpacerItem *verticalSpacer_2;
    QSpacerItem *horizontalSpacer;
    QSpacerItem *horizontalSpacer_2;
    QGridLayout *gridLayout_2;
    QGroupBox *groupBox;
    QVBoxLayout *verticalLayout;
    QRadioButton *radioButton;
    QRadioButton *radioButton_2;
    QRadioButton *radioButton_3;
    QPlainTextEdit *plainTextEdit;
    ColorButton *widgetBgColor;
    QLabel *label;
    QCheckBox *useKerningCheckBox;
    QSpacerItem *verticalSpacer_3;

    void setupUi(QWidget *FontTestFrame)
    {
        if (FontTestFrame->objectName().isEmpty())
            FontTestFrame->setObjectName(QString::fromUtf8("FontTestFrame"));
        FontTestFrame->resize(474, 361);
        QSizePolicy sizePolicy(QSizePolicy::Minimum, QSizePolicy::Minimum);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(FontTestFrame->sizePolicy().hasHeightForWidth());
        FontTestFrame->setSizePolicy(sizePolicy);
        verticalLayout_2 = new QVBoxLayout(FontTestFrame);
        verticalLayout_2->setContentsMargins(0, 0, 0, 0);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        scrollArea = new QScrollArea(FontTestFrame);
        scrollArea->setObjectName(QString::fromUtf8("scrollArea"));
        QSizePolicy sizePolicy1(QSizePolicy::Expanding, QSizePolicy::Expanding);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(2);
        sizePolicy1.setHeightForWidth(scrollArea->sizePolicy().hasHeightForWidth());
        scrollArea->setSizePolicy(sizePolicy1);
        scrollArea->setWidgetResizable(true);
        scrollAreaWidgetContents = new QWidget();
        scrollAreaWidgetContents->setObjectName(QString::fromUtf8("scrollAreaWidgetContents"));
        scrollAreaWidgetContents->setGeometry(QRect(0, 0, 470, 144));
        gridLayout = new QGridLayout(scrollAreaWidgetContents);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        drawWidget = new FontTestWidget(scrollAreaWidgetContents);
        drawWidget->setObjectName(QString::fromUtf8("drawWidget"));

        gridLayout->addWidget(drawWidget, 2, 1, 1, 1);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout->addItem(verticalSpacer, 4, 1, 1, 1);

        verticalSpacer_2 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout->addItem(verticalSpacer_2, 0, 1, 1, 1);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout->addItem(horizontalSpacer, 2, 2, 1, 1);

        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout->addItem(horizontalSpacer_2, 2, 0, 1, 1);

        scrollArea->setWidget(scrollAreaWidgetContents);

        verticalLayout_2->addWidget(scrollArea);

        gridLayout_2 = new QGridLayout();
        gridLayout_2->setObjectName(QString::fromUtf8("gridLayout_2"));
        groupBox = new QGroupBox(FontTestFrame);
        groupBox->setObjectName(QString::fromUtf8("groupBox"));
        sizePolicy.setHeightForWidth(groupBox->sizePolicy().hasHeightForWidth());
        groupBox->setSizePolicy(sizePolicy);
        groupBox->setMinimumSize(QSize(94, 0));
        verticalLayout = new QVBoxLayout(groupBox);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        radioButton = new QRadioButton(groupBox);
        radioButton->setObjectName(QString::fromUtf8("radioButton"));

        verticalLayout->addWidget(radioButton);

        radioButton_2 = new QRadioButton(groupBox);
        radioButton_2->setObjectName(QString::fromUtf8("radioButton_2"));
        radioButton_2->setChecked(true);

        verticalLayout->addWidget(radioButton_2);

        radioButton_3 = new QRadioButton(groupBox);
        radioButton_3->setObjectName(QString::fromUtf8("radioButton_3"));

        verticalLayout->addWidget(radioButton_3);


        gridLayout_2->addWidget(groupBox, 0, 0, 1, 2);

        plainTextEdit = new QPlainTextEdit(FontTestFrame);
        plainTextEdit->setObjectName(QString::fromUtf8("plainTextEdit"));
        QSizePolicy sizePolicy2(QSizePolicy::Minimum, QSizePolicy::Expanding);
        sizePolicy2.setHorizontalStretch(0);
        sizePolicy2.setVerticalStretch(0);
        sizePolicy2.setHeightForWidth(plainTextEdit->sizePolicy().hasHeightForWidth());
        plainTextEdit->setSizePolicy(sizePolicy2);
        plainTextEdit->setMaximumSize(QSize(16777215, 16777215));

        gridLayout_2->addWidget(plainTextEdit, 0, 2, 4, 1);

        widgetBgColor = new ColorButton(FontTestFrame);
        widgetBgColor->setObjectName(QString::fromUtf8("widgetBgColor"));
        widgetBgColor->setMinimumSize(QSize(32, 20));

        gridLayout_2->addWidget(widgetBgColor, 1, 1, 1, 1);

        label = new QLabel(FontTestFrame);
        label->setObjectName(QString::fromUtf8("label"));

        gridLayout_2->addWidget(label, 1, 0, 1, 1);

        useKerningCheckBox = new QCheckBox(FontTestFrame);
        useKerningCheckBox->setObjectName(QString::fromUtf8("useKerningCheckBox"));

        gridLayout_2->addWidget(useKerningCheckBox, 2, 0, 1, 2);

        verticalSpacer_3 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout_2->addItem(verticalSpacer_3, 3, 0, 1, 2);

        gridLayout_2->setColumnStretch(2, 1);

        verticalLayout_2->addLayout(gridLayout_2);

        verticalLayout_2->setStretch(0, 1);

        retranslateUi(FontTestFrame);

        QMetaObject::connectSlotsByName(FontTestFrame);
    } // setupUi

    void retranslateUi(QWidget *FontTestFrame)
    {
        FontTestFrame->setWindowTitle(QApplication::translate("FontTestFrame", "Frame", 0, QApplication::UnicodeUTF8));
        groupBox->setTitle(QApplication::translate("FontTestFrame", "Align", 0, QApplication::UnicodeUTF8));
        radioButton->setText(QApplication::translate("FontTestFrame", "Left", 0, QApplication::UnicodeUTF8));
        radioButton_2->setText(QApplication::translate("FontTestFrame", "Center", 0, QApplication::UnicodeUTF8));
        radioButton_3->setText(QApplication::translate("FontTestFrame", "Right", 0, QApplication::UnicodeUTF8));
        plainTextEdit->setPlainText(QApplication::translate("FontTestFrame", "Test", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("FontTestFrame", "BG color:", 0, QApplication::UnicodeUTF8));
        useKerningCheckBox->setText(QApplication::translate("FontTestFrame", "Use kerning", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class FontTestFrame: public Ui_FontTestFrame {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_FONTTESTFRAME_H
