/********************************************************************************
** Form generated from reading UI file 'fontoptionsframe.ui'
**
** Created by: Qt User Interface Compiler version 4.8.6
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_FONTOPTIONSFRAME_H
#define UI_FONTOPTIONSFRAME_H

#include <QtCore/QLocale>
#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QCheckBox>
#include <QtGui/QComboBox>
#include <QtGui/QDoubleSpinBox>
#include <QtGui/QGridLayout>
#include <QtGui/QGroupBox>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QSlider>
#include <QtGui/QSpacerItem>
#include <QtGui/QSpinBox>
#include <QtGui/QVBoxLayout>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_FontOptionsFrame
{
public:
    QVBoxLayout *verticalLayout;
    QGridLayout *gridLayout_4;
    QCheckBox *checkBoxMissingGlypths;
    QComboBox *comboBoxDPI;
    QSpacerItem *horizontalSpacer;
    QLabel *label_5;
    QLabel *label_7;
    QComboBox *comboBox_Hinting;
    QCheckBox *checkBoxSmoothing;
    QGridLayout *gridLayout_3;
    QSlider *horizontalSliderBold;
    QLabel *labelBold_t;
    QSlider *horizontalSliderItalic;
    QLabel *label_3;
    QLabel *labelBold;
    QLabel *labelItalic;
    QGroupBox *groupBox_2;
    QGridLayout *gridLayout;
    QLabel *label_6;
    QLabel *label;
    QDoubleSpinBox *doubleSpinBoxWidth;
    QDoubleSpinBox *doubleSpinBoxHeight;
    QGroupBox *groupBox;
    QGridLayout *gridLayout_5;
    QLabel *label_2;
    QSpinBox *spinBoxCharSpacing;
    QLabel *label_4;
    QSpinBox *spinBoxLineSpacing;

    void setupUi(QWidget *FontOptionsFrame)
    {
        if (FontOptionsFrame->objectName().isEmpty())
            FontOptionsFrame->setObjectName(QString::fromUtf8("FontOptionsFrame"));
        FontOptionsFrame->resize(338, 272);
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Minimum);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(FontOptionsFrame->sizePolicy().hasHeightForWidth());
        FontOptionsFrame->setSizePolicy(sizePolicy);
        FontOptionsFrame->setLocale(QLocale(QLocale::English, QLocale::UnitedStates));
        verticalLayout = new QVBoxLayout(FontOptionsFrame);
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalLayout->setSizeConstraint(QLayout::SetMinimumSize);
        gridLayout_4 = new QGridLayout();
        gridLayout_4->setObjectName(QString::fromUtf8("gridLayout_4"));
        checkBoxMissingGlypths = new QCheckBox(FontOptionsFrame);
        checkBoxMissingGlypths->setObjectName(QString::fromUtf8("checkBoxMissingGlypths"));

        gridLayout_4->addWidget(checkBoxMissingGlypths, 1, 2, 1, 3);

        comboBoxDPI = new QComboBox(FontOptionsFrame);
        comboBoxDPI->setObjectName(QString::fromUtf8("comboBoxDPI"));

        gridLayout_4->addWidget(comboBoxDPI, 0, 4, 1, 1);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_4->addItem(horizontalSpacer, 0, 2, 1, 1);

        label_5 = new QLabel(FontOptionsFrame);
        label_5->setObjectName(QString::fromUtf8("label_5"));

        gridLayout_4->addWidget(label_5, 0, 3, 1, 1);

        label_7 = new QLabel(FontOptionsFrame);
        label_7->setObjectName(QString::fromUtf8("label_7"));

        gridLayout_4->addWidget(label_7, 1, 0, 1, 1);

        comboBox_Hinting = new QComboBox(FontOptionsFrame);
        comboBox_Hinting->setObjectName(QString::fromUtf8("comboBox_Hinting"));

        gridLayout_4->addWidget(comboBox_Hinting, 1, 1, 1, 1);

        checkBoxSmoothing = new QCheckBox(FontOptionsFrame);
        checkBoxSmoothing->setObjectName(QString::fromUtf8("checkBoxSmoothing"));

        gridLayout_4->addWidget(checkBoxSmoothing, 0, 0, 1, 2);


        verticalLayout->addLayout(gridLayout_4);

        gridLayout_3 = new QGridLayout();
        gridLayout_3->setObjectName(QString::fromUtf8("gridLayout_3"));
        gridLayout_3->setSizeConstraint(QLayout::SetMinimumSize);
        horizontalSliderBold = new QSlider(FontOptionsFrame);
        horizontalSliderBold->setObjectName(QString::fromUtf8("horizontalSliderBold"));
        horizontalSliderBold->setMinimum(-10);
        horizontalSliderBold->setMaximum(10);
        horizontalSliderBold->setPageStep(2);
        horizontalSliderBold->setTracking(true);
        horizontalSliderBold->setOrientation(Qt::Horizontal);
        horizontalSliderBold->setTickPosition(QSlider::TicksBothSides);

        gridLayout_3->addWidget(horizontalSliderBold, 3, 2, 1, 1);

        labelBold_t = new QLabel(FontOptionsFrame);
        labelBold_t->setObjectName(QString::fromUtf8("labelBold_t"));

        gridLayout_3->addWidget(labelBold_t, 3, 0, 1, 1);

        horizontalSliderItalic = new QSlider(FontOptionsFrame);
        horizontalSliderItalic->setObjectName(QString::fromUtf8("horizontalSliderItalic"));
        horizontalSliderItalic->setMinimum(-20);
        horizontalSliderItalic->setMaximum(20);
        horizontalSliderItalic->setOrientation(Qt::Horizontal);
        horizontalSliderItalic->setTickPosition(QSlider::TicksBothSides);

        gridLayout_3->addWidget(horizontalSliderItalic, 4, 2, 1, 1);

        label_3 = new QLabel(FontOptionsFrame);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        gridLayout_3->addWidget(label_3, 4, 0, 1, 1);

        labelBold = new QLabel(FontOptionsFrame);
        labelBold->setObjectName(QString::fromUtf8("labelBold"));
        labelBold->setMinimumSize(QSize(32, 0));
        labelBold->setTextFormat(Qt::PlainText);
        labelBold->setAlignment(Qt::AlignCenter);

        gridLayout_3->addWidget(labelBold, 3, 1, 1, 1);

        labelItalic = new QLabel(FontOptionsFrame);
        labelItalic->setObjectName(QString::fromUtf8("labelItalic"));
        labelItalic->setMinimumSize(QSize(32, 0));
        labelItalic->setTextFormat(Qt::PlainText);
        labelItalic->setAlignment(Qt::AlignCenter);

        gridLayout_3->addWidget(labelItalic, 4, 1, 1, 1);


        verticalLayout->addLayout(gridLayout_3);

        groupBox_2 = new QGroupBox(FontOptionsFrame);
        groupBox_2->setObjectName(QString::fromUtf8("groupBox_2"));
        sizePolicy.setHeightForWidth(groupBox_2->sizePolicy().hasHeightForWidth());
        groupBox_2->setSizePolicy(sizePolicy);
        gridLayout = new QGridLayout(groupBox_2);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        label_6 = new QLabel(groupBox_2);
        label_6->setObjectName(QString::fromUtf8("label_6"));

        gridLayout->addWidget(label_6, 0, 0, 1, 1);

        label = new QLabel(groupBox_2);
        label->setObjectName(QString::fromUtf8("label"));

        gridLayout->addWidget(label, 0, 2, 1, 1);

        doubleSpinBoxWidth = new QDoubleSpinBox(groupBox_2);
        doubleSpinBoxWidth->setObjectName(QString::fromUtf8("doubleSpinBoxWidth"));
        doubleSpinBoxWidth->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        doubleSpinBoxWidth->setMaximum(200);
        doubleSpinBoxWidth->setValue(100);

        gridLayout->addWidget(doubleSpinBoxWidth, 0, 1, 1, 1);

        doubleSpinBoxHeight = new QDoubleSpinBox(groupBox_2);
        doubleSpinBoxHeight->setObjectName(QString::fromUtf8("doubleSpinBoxHeight"));
        doubleSpinBoxHeight->setMaximum(200);
        doubleSpinBoxHeight->setValue(100);

        gridLayout->addWidget(doubleSpinBoxHeight, 0, 3, 1, 1);


        verticalLayout->addWidget(groupBox_2);

        groupBox = new QGroupBox(FontOptionsFrame);
        groupBox->setObjectName(QString::fromUtf8("groupBox"));
        gridLayout_5 = new QGridLayout(groupBox);
        gridLayout_5->setObjectName(QString::fromUtf8("gridLayout_5"));
        label_2 = new QLabel(groupBox);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        gridLayout_5->addWidget(label_2, 0, 0, 1, 1);

        spinBoxCharSpacing = new QSpinBox(groupBox);
        spinBoxCharSpacing->setObjectName(QString::fromUtf8("spinBoxCharSpacing"));
        spinBoxCharSpacing->setMinimum(-99);

        gridLayout_5->addWidget(spinBoxCharSpacing, 0, 1, 1, 1);

        label_4 = new QLabel(groupBox);
        label_4->setObjectName(QString::fromUtf8("label_4"));

        gridLayout_5->addWidget(label_4, 0, 2, 1, 1);

        spinBoxLineSpacing = new QSpinBox(groupBox);
        spinBoxLineSpacing->setObjectName(QString::fromUtf8("spinBoxLineSpacing"));
        spinBoxLineSpacing->setMinimum(-99);

        gridLayout_5->addWidget(spinBoxLineSpacing, 0, 3, 1, 1);


        verticalLayout->addWidget(groupBox);

#ifndef QT_NO_SHORTCUT
        labelBold_t->setBuddy(horizontalSliderBold);
        label_3->setBuddy(horizontalSliderItalic);
        label_6->setBuddy(doubleSpinBoxWidth);
        label->setBuddy(doubleSpinBoxHeight);
        label_2->setBuddy(spinBoxCharSpacing);
        label_4->setBuddy(spinBoxLineSpacing);
#endif // QT_NO_SHORTCUT

        retranslateUi(FontOptionsFrame);

        QMetaObject::connectSlotsByName(FontOptionsFrame);
    } // setupUi

    void retranslateUi(QWidget *FontOptionsFrame)
    {
        FontOptionsFrame->setWindowTitle(QApplication::translate("FontOptionsFrame", "Frame", 0, QApplication::UnicodeUTF8));
        checkBoxMissingGlypths->setText(QApplication::translate("FontOptionsFrame", "Show missing glypths", 0, QApplication::UnicodeUTF8));
        comboBoxDPI->clear();
        comboBoxDPI->insertItems(0, QStringList()
         << QApplication::translate("FontOptionsFrame", "72", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("FontOptionsFrame", "96", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("FontOptionsFrame", "100", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("FontOptionsFrame", "110", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("FontOptionsFrame", "120", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("FontOptionsFrame", "128", 0, QApplication::UnicodeUTF8)
        );
        label_5->setText(QApplication::translate("FontOptionsFrame", "DPI:", 0, QApplication::UnicodeUTF8));
        label_7->setText(QApplication::translate("FontOptionsFrame", "Hinting:", 0, QApplication::UnicodeUTF8));
        comboBox_Hinting->clear();
        comboBox_Hinting->insertItems(0, QStringList()
         << QApplication::translate("FontOptionsFrame", "Disabled", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("FontOptionsFrame", "Default", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("FontOptionsFrame", "ForceFreetypeAutohinting", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("FontOptionsFrame", "DisableFreetypeAutohinting", 0, QApplication::UnicodeUTF8)
        );
        checkBoxSmoothing->setText(QApplication::translate("FontOptionsFrame", "Smoothing", 0, QApplication::UnicodeUTF8));
        labelBold_t->setText(QApplication::translate("FontOptionsFrame", "Faux bold", 0, QApplication::UnicodeUTF8));
        label_3->setText(QApplication::translate("FontOptionsFrame", "Faux italic", 0, QApplication::UnicodeUTF8));
        labelBold->setText(QApplication::translate("FontOptionsFrame", "0", 0, QApplication::UnicodeUTF8));
        labelItalic->setText(QApplication::translate("FontOptionsFrame", "0", 0, QApplication::UnicodeUTF8));
        groupBox_2->setTitle(QApplication::translate("FontOptionsFrame", "Scale, %", 0, QApplication::UnicodeUTF8));
        label_6->setText(QApplication::translate("FontOptionsFrame", "Width", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("FontOptionsFrame", "Height", 0, QApplication::UnicodeUTF8));
        groupBox->setTitle(QApplication::translate("FontOptionsFrame", "Spacing", 0, QApplication::UnicodeUTF8));
        label_2->setText(QApplication::translate("FontOptionsFrame", "Char", 0, QApplication::UnicodeUTF8));
        label_4->setText(QApplication::translate("FontOptionsFrame", "Line", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class FontOptionsFrame: public Ui_FontOptionsFrame {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_FONTOPTIONSFRAME_H
