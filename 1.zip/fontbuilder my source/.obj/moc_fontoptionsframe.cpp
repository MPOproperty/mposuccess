/****************************************************************************
** Meta object code from reading C++ file 'fontoptionsframe.h'
**
** Created by: The Qt Meta Object Compiler version 63 (Qt 4.8.6)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../src/fontoptionsframe.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'fontoptionsframe.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.6. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_FontOptionsFrame[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
      11,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      18,   17,   17,   17, 0x08,
      62,   17,   17,   17, 0x08,
     102,   17,   17,   17, 0x08,
     142,   17,   17,   17, 0x08,
     186,   17,   17,   17, 0x08,
     235,  229,   17,   17, 0x08,
     279,  229,   17,   17, 0x08,
     329,  321,   17,   17, 0x08,
     364,  321,   17,   17, 0x08,
     404,  321,   17,   17, 0x08,
     447,  441,   17,   17, 0x08,

       0        // eod
};

static const char qt_meta_stringdata_FontOptionsFrame[] = {
    "FontOptionsFrame\0\0"
    "on_comboBoxDPI_currentIndexChanged(QString)\0"
    "on_spinBoxLineSpacing_valueChanged(int)\0"
    "on_spinBoxCharSpacing_valueChanged(int)\0"
    "on_doubleSpinBoxHeight_valueChanged(double)\0"
    "on_doubleSpinBoxWidth_valueChanged(double)\0"
    "value\0on_horizontalSliderItalic_valueChanged(int)\0"
    "on_horizontalSliderBold_valueChanged(int)\0"
    "checked\0on_checkBoxSmoothing_toggled(bool)\0"
    "on_checkBoxMissingGlypths_toggled(bool)\0"
    "on_checkBoxAutohinting_toggled(bool)\0"
    "index\0on_comboBox_Hinting_currentIndexChanged(int)\0"
};

void FontOptionsFrame::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        FontOptionsFrame *_t = static_cast<FontOptionsFrame *>(_o);
        switch (_id) {
        case 0: _t->on_comboBoxDPI_currentIndexChanged((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 1: _t->on_spinBoxLineSpacing_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 2: _t->on_spinBoxCharSpacing_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 3: _t->on_doubleSpinBoxHeight_valueChanged((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 4: _t->on_doubleSpinBoxWidth_valueChanged((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 5: _t->on_horizontalSliderItalic_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 6: _t->on_horizontalSliderBold_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 7: _t->on_checkBoxSmoothing_toggled((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 8: _t->on_checkBoxMissingGlypths_toggled((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 9: _t->on_checkBoxAutohinting_toggled((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 10: _t->on_comboBox_Hinting_currentIndexChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData FontOptionsFrame::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject FontOptionsFrame::staticMetaObject = {
    { &QFrame::staticMetaObject, qt_meta_stringdata_FontOptionsFrame,
      qt_meta_data_FontOptionsFrame, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &FontOptionsFrame::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *FontOptionsFrame::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *FontOptionsFrame::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_FontOptionsFrame))
        return static_cast<void*>(const_cast< FontOptionsFrame*>(this));
    return QFrame::qt_metacast(_clname);
}

int FontOptionsFrame::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QFrame::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 11)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 11;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
