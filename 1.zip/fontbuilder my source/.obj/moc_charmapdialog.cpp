/****************************************************************************
** Meta object code from reading C++ file 'charmapdialog.h'
**
** Created by: The Qt Meta Object Compiler version 63 (Qt 4.8.6)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../src/charmapdialog.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'charmapdialog.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.6. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_CharMapDialog[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       3,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      20,   15,   14,   14, 0x08,
      81,   64,   14,   14, 0x08,
     158,  149,   14,   14, 0x08,

       0        // eod
};

static const char qt_meta_stringdata_CharMapDialog[] = {
    "CharMapDialog\0\0item\0"
    "on_listWidget_itemChanged(QListWidgetItem*)\0"
    "current,previous\0"
    "on_listWidget_currentItemChanged(QListWidgetItem*,QListWidgetItem*)\0"
    "code,add\0onCharsChanged(uint,bool)\0"
};

void CharMapDialog::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        CharMapDialog *_t = static_cast<CharMapDialog *>(_o);
        switch (_id) {
        case 0: _t->on_listWidget_itemChanged((*reinterpret_cast< QListWidgetItem*(*)>(_a[1]))); break;
        case 1: _t->on_listWidget_currentItemChanged((*reinterpret_cast< QListWidgetItem*(*)>(_a[1])),(*reinterpret_cast< QListWidgetItem*(*)>(_a[2]))); break;
        case 2: _t->onCharsChanged((*reinterpret_cast< uint(*)>(_a[1])),(*reinterpret_cast< bool(*)>(_a[2]))); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData CharMapDialog::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject CharMapDialog::staticMetaObject = {
    { &QDialog::staticMetaObject, qt_meta_stringdata_CharMapDialog,
      qt_meta_data_CharMapDialog, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &CharMapDialog::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *CharMapDialog::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *CharMapDialog::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_CharMapDialog))
        return static_cast<void*>(const_cast< CharMapDialog*>(this));
    return QDialog::qt_metacast(_clname);
}

int CharMapDialog::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QDialog::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 3)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 3;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
