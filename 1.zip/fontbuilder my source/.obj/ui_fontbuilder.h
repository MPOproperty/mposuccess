/********************************************************************************
** Form generated from reading UI file 'fontbuilder.ui'
**
** Created by: Qt User Interface Compiler version 4.8.6
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_FONTBUILDER_H
#define UI_FONTBUILDER_H

#include <QtCore/QLocale>
#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QCheckBox>
#include <QtGui/QComboBox>
#include <QtGui/QGridLayout>
#include <QtGui/QGroupBox>
#include <QtGui/QHBoxLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QMainWindow>
#include <QtGui/QMenu>
#include <QtGui/QMenuBar>
#include <QtGui/QPushButton>
#include <QtGui/QScrollArea>
#include <QtGui/QSpacerItem>
#include <QtGui/QStatusBar>
#include <QtGui/QTabWidget>
#include <QtGui/QVBoxLayout>
#include <QtGui/QWidget>
#include "charactersframe.h"
#include "fontdrawwidget.h"
#include "fontoptionsframe.h"
#include "fontselectframe.h"
#include "fonttestframe.h"
#include "layoutconfigframe.h"
#include "outputframe.h"

QT_BEGIN_NAMESPACE

class Ui_FontBuilder
{
public:
    QAction *action_Open;
    QWidget *centralWidget;
    QHBoxLayout *horizontalLayout;
    QTabWidget *tabWidget;
    QWidget *tab_Font;
    QVBoxLayout *verticalLayout_2;
    QGroupBox *groupBox_FontSelect;
    QHBoxLayout *horizontalLayout_2;
    FontSelectFrame *frameFontSelect;
    QGroupBox *groupBox;
    QVBoxLayout *verticalLayout_3;
    FontOptionsFrame *frameFontOptions;
    QSpacerItem *verticalSpacer;
    QWidget *tab_Charaters;
    QVBoxLayout *verticalLayout_4;
    CharactersFrame *frameCharacters;
    QWidget *tab_Layout;
    QVBoxLayout *verticalLayout_5;
    QLabel *label;
    QComboBox *comboBoxLayouter;
    LayoutConfigFrame *frameLayoutConfig;
    QSpacerItem *verticalSpacer_2;
    QWidget *tab_Output;
    QVBoxLayout *verticalLayout_7;
    OutputFrame *frameOutput;
    QPushButton *pushButtonWriteFont;
    QTabWidget *tabWidget_2;
    QWidget *tab_Preview;
    QGridLayout *gridLayout_2;
    QScrollArea *scrollArea;
    QWidget *scrollAreaWidgetContents;
    QGridLayout *gridLayout;
    QSpacerItem *verticalSpacer_3;
    QSpacerItem *verticalSpacer_4;
    FontDrawWidget *widgetFontPreview;
    QSpacerItem *horizontalSpacer;
    QSpacerItem *horizontalSpacer_2;
    QCheckBox *checkBoxDrawGrid;
    QLabel *label_ImageSize;
    QLabel *label_2;
    QComboBox *comboBox;
    QWidget *tab_TestFont;
    QGridLayout *gridLayout_3;
    FontTestFrame *fontTestFrame;
    QMenuBar *menuBar;
    QMenu *menu_File;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *FontBuilder)
    {
        if (FontBuilder->objectName().isEmpty())
            FontBuilder->setObjectName(QString::fromUtf8("FontBuilder"));
        FontBuilder->resize(612, 560);
        FontBuilder->setLocale(QLocale(QLocale::English, QLocale::UnitedStates));
        action_Open = new QAction(FontBuilder);
        action_Open->setObjectName(QString::fromUtf8("action_Open"));
        centralWidget = new QWidget(FontBuilder);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        horizontalLayout = new QHBoxLayout(centralWidget);
        horizontalLayout->setSpacing(6);
        horizontalLayout->setContentsMargins(11, 11, 11, 11);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        tabWidget = new QTabWidget(centralWidget);
        tabWidget->setObjectName(QString::fromUtf8("tabWidget"));
        tabWidget->setLocale(QLocale(QLocale::English, QLocale::UnitedStates));
        tab_Font = new QWidget();
        tab_Font->setObjectName(QString::fromUtf8("tab_Font"));
        verticalLayout_2 = new QVBoxLayout(tab_Font);
        verticalLayout_2->setSpacing(6);
        verticalLayout_2->setContentsMargins(11, 11, 11, 11);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        groupBox_FontSelect = new QGroupBox(tab_Font);
        groupBox_FontSelect->setObjectName(QString::fromUtf8("groupBox_FontSelect"));
        QSizePolicy sizePolicy(QSizePolicy::Minimum, QSizePolicy::Minimum);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(groupBox_FontSelect->sizePolicy().hasHeightForWidth());
        groupBox_FontSelect->setSizePolicy(sizePolicy);
        horizontalLayout_2 = new QHBoxLayout(groupBox_FontSelect);
        horizontalLayout_2->setSpacing(6);
        horizontalLayout_2->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        frameFontSelect = new FontSelectFrame(groupBox_FontSelect);
        frameFontSelect->setObjectName(QString::fromUtf8("frameFontSelect"));
        sizePolicy.setHeightForWidth(frameFontSelect->sizePolicy().hasHeightForWidth());
        frameFontSelect->setSizePolicy(sizePolicy);

        horizontalLayout_2->addWidget(frameFontSelect);


        verticalLayout_2->addWidget(groupBox_FontSelect);

        groupBox = new QGroupBox(tab_Font);
        groupBox->setObjectName(QString::fromUtf8("groupBox"));
        verticalLayout_3 = new QVBoxLayout(groupBox);
        verticalLayout_3->setSpacing(6);
        verticalLayout_3->setContentsMargins(11, 11, 11, 11);
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        frameFontOptions = new FontOptionsFrame(groupBox);
        frameFontOptions->setObjectName(QString::fromUtf8("frameFontOptions"));
        sizePolicy.setHeightForWidth(frameFontOptions->sizePolicy().hasHeightForWidth());
        frameFontOptions->setSizePolicy(sizePolicy);

        verticalLayout_3->addWidget(frameFontOptions);


        verticalLayout_2->addWidget(groupBox);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_2->addItem(verticalSpacer);

        tabWidget->addTab(tab_Font, QString());
        tab_Charaters = new QWidget();
        tab_Charaters->setObjectName(QString::fromUtf8("tab_Charaters"));
        verticalLayout_4 = new QVBoxLayout(tab_Charaters);
        verticalLayout_4->setSpacing(6);
        verticalLayout_4->setContentsMargins(11, 11, 11, 11);
        verticalLayout_4->setObjectName(QString::fromUtf8("verticalLayout_4"));
        frameCharacters = new CharactersFrame(tab_Charaters);
        frameCharacters->setObjectName(QString::fromUtf8("frameCharacters"));

        verticalLayout_4->addWidget(frameCharacters);

        tabWidget->addTab(tab_Charaters, QString());
        tab_Layout = new QWidget();
        tab_Layout->setObjectName(QString::fromUtf8("tab_Layout"));
        verticalLayout_5 = new QVBoxLayout(tab_Layout);
        verticalLayout_5->setSpacing(6);
        verticalLayout_5->setContentsMargins(11, 11, 11, 11);
        verticalLayout_5->setObjectName(QString::fromUtf8("verticalLayout_5"));
        label = new QLabel(tab_Layout);
        label->setObjectName(QString::fromUtf8("label"));

        verticalLayout_5->addWidget(label);

        comboBoxLayouter = new QComboBox(tab_Layout);
        comboBoxLayouter->setObjectName(QString::fromUtf8("comboBoxLayouter"));

        verticalLayout_5->addWidget(comboBoxLayouter);

        frameLayoutConfig = new LayoutConfigFrame(tab_Layout);
        frameLayoutConfig->setObjectName(QString::fromUtf8("frameLayoutConfig"));

        verticalLayout_5->addWidget(frameLayoutConfig);

        verticalSpacer_2 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_5->addItem(verticalSpacer_2);

        tabWidget->addTab(tab_Layout, QString());
        tab_Output = new QWidget();
        tab_Output->setObjectName(QString::fromUtf8("tab_Output"));
        verticalLayout_7 = new QVBoxLayout(tab_Output);
        verticalLayout_7->setSpacing(6);
        verticalLayout_7->setContentsMargins(11, 11, 11, 11);
        verticalLayout_7->setObjectName(QString::fromUtf8("verticalLayout_7"));
        frameOutput = new OutputFrame(tab_Output);
        frameOutput->setObjectName(QString::fromUtf8("frameOutput"));

        verticalLayout_7->addWidget(frameOutput);

        pushButtonWriteFont = new QPushButton(tab_Output);
        pushButtonWriteFont->setObjectName(QString::fromUtf8("pushButtonWriteFont"));

        verticalLayout_7->addWidget(pushButtonWriteFont);

        tabWidget->addTab(tab_Output, QString());

        horizontalLayout->addWidget(tabWidget);

        tabWidget_2 = new QTabWidget(centralWidget);
        tabWidget_2->setObjectName(QString::fromUtf8("tabWidget_2"));
        tab_Preview = new QWidget();
        tab_Preview->setObjectName(QString::fromUtf8("tab_Preview"));
        gridLayout_2 = new QGridLayout(tab_Preview);
        gridLayout_2->setSpacing(6);
        gridLayout_2->setContentsMargins(11, 11, 11, 11);
        gridLayout_2->setObjectName(QString::fromUtf8("gridLayout_2"));
        scrollArea = new QScrollArea(tab_Preview);
        scrollArea->setObjectName(QString::fromUtf8("scrollArea"));
        scrollArea->setWidgetResizable(true);
        scrollAreaWidgetContents = new QWidget();
        scrollAreaWidgetContents->setObjectName(QString::fromUtf8("scrollAreaWidgetContents"));
        scrollAreaWidgetContents->setGeometry(QRect(0, 0, 246, 406));
        gridLayout = new QGridLayout(scrollAreaWidgetContents);
        gridLayout->setSpacing(6);
        gridLayout->setContentsMargins(11, 11, 11, 11);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        verticalSpacer_3 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout->addItem(verticalSpacer_3, 4, 0, 1, 4);

        verticalSpacer_4 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout->addItem(verticalSpacer_4, 0, 0, 1, 4);

        widgetFontPreview = new FontDrawWidget(scrollAreaWidgetContents);
        widgetFontPreview->setObjectName(QString::fromUtf8("widgetFontPreview"));

        gridLayout->addWidget(widgetFontPreview, 2, 1, 1, 2);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout->addItem(horizontalSpacer, 2, 3, 1, 1);

        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout->addItem(horizontalSpacer_2, 2, 0, 1, 1);

        scrollArea->setWidget(scrollAreaWidgetContents);

        gridLayout_2->addWidget(scrollArea, 3, 0, 1, 4);

        checkBoxDrawGrid = new QCheckBox(tab_Preview);
        checkBoxDrawGrid->setObjectName(QString::fromUtf8("checkBoxDrawGrid"));

        gridLayout_2->addWidget(checkBoxDrawGrid, 1, 0, 1, 1);

        label_ImageSize = new QLabel(tab_Preview);
        label_ImageSize->setObjectName(QString::fromUtf8("label_ImageSize"));

        gridLayout_2->addWidget(label_ImageSize, 1, 1, 1, 1);

        label_2 = new QLabel(tab_Preview);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        gridLayout_2->addWidget(label_2, 1, 2, 1, 1);

        comboBox = new QComboBox(tab_Preview);
        comboBox->setObjectName(QString::fromUtf8("comboBox"));
        comboBox->setLayoutDirection(Qt::LeftToRight);
        comboBox->setFrame(true);

        gridLayout_2->addWidget(comboBox, 1, 3, 1, 1);

        gridLayout_2->setColumnStretch(0, 1);
        gridLayout_2->setColumnStretch(1, 1);
        tabWidget_2->addTab(tab_Preview, QString());
        tab_TestFont = new QWidget();
        tab_TestFont->setObjectName(QString::fromUtf8("tab_TestFont"));
        gridLayout_3 = new QGridLayout(tab_TestFont);
        gridLayout_3->setSpacing(6);
        gridLayout_3->setContentsMargins(11, 11, 11, 11);
        gridLayout_3->setObjectName(QString::fromUtf8("gridLayout_3"));
        fontTestFrame = new FontTestFrame(tab_TestFont);
        fontTestFrame->setObjectName(QString::fromUtf8("fontTestFrame"));

        gridLayout_3->addWidget(fontTestFrame, 0, 0, 1, 1);

        tabWidget_2->addTab(tab_TestFont, QString());

        horizontalLayout->addWidget(tabWidget_2);

        horizontalLayout->setStretch(1, 1);
        FontBuilder->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(FontBuilder);
        menuBar->setObjectName(QString::fromUtf8("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 612, 22));
        menu_File = new QMenu(menuBar);
        menu_File->setObjectName(QString::fromUtf8("menu_File"));
        FontBuilder->setMenuBar(menuBar);
        statusBar = new QStatusBar(FontBuilder);
        statusBar->setObjectName(QString::fromUtf8("statusBar"));
        FontBuilder->setStatusBar(statusBar);

        menuBar->addAction(menu_File->menuAction());
        menu_File->addAction(action_Open);

        retranslateUi(FontBuilder);

        tabWidget->setCurrentIndex(0);
        tabWidget_2->setCurrentIndex(0);
        comboBox->setCurrentIndex(1);


        QMetaObject::connectSlotsByName(FontBuilder);
    } // setupUi

    void retranslateUi(QMainWindow *FontBuilder)
    {
        FontBuilder->setWindowTitle(QApplication::translate("FontBuilder", "FontBuilder", 0, QApplication::UnicodeUTF8));
        action_Open->setText(QApplication::translate("FontBuilder", "&Open", 0, QApplication::UnicodeUTF8));
        groupBox_FontSelect->setTitle(QApplication::translate("FontBuilder", "Font", 0, QApplication::UnicodeUTF8));
        groupBox->setTitle(QApplication::translate("FontBuilder", "Options", 0, QApplication::UnicodeUTF8));
        tabWidget->setTabText(tabWidget->indexOf(tab_Font), QApplication::translate("FontBuilder", "Font", 0, QApplication::UnicodeUTF8));
        tabWidget->setTabText(tabWidget->indexOf(tab_Charaters), QApplication::translate("FontBuilder", "Characters", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("FontBuilder", "Layout engine", 0, QApplication::UnicodeUTF8));
        tabWidget->setTabText(tabWidget->indexOf(tab_Layout), QApplication::translate("FontBuilder", "Layout", 0, QApplication::UnicodeUTF8));
        pushButtonWriteFont->setText(QApplication::translate("FontBuilder", "Write font", 0, QApplication::UnicodeUTF8));
        tabWidget->setTabText(tabWidget->indexOf(tab_Output), QApplication::translate("FontBuilder", "Output", 0, QApplication::UnicodeUTF8));
        checkBoxDrawGrid->setText(QApplication::translate("FontBuilder", "Draw grid", 0, QApplication::UnicodeUTF8));
        label_ImageSize->setText(QApplication::translate("FontBuilder", "0x0", 0, QApplication::UnicodeUTF8));
        label_2->setText(QApplication::translate("FontBuilder", "scale:", 0, QApplication::UnicodeUTF8));
        comboBox->clear();
        comboBox->insertItems(0, QStringList()
         << QApplication::translate("FontBuilder", "50%", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("FontBuilder", "100%", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("FontBuilder", "200%", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("FontBuilder", "400%", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("FontBuilder", "800%", 0, QApplication::UnicodeUTF8)
        );
        tabWidget_2->setTabText(tabWidget_2->indexOf(tab_Preview), QApplication::translate("FontBuilder", "Font image preview", 0, QApplication::UnicodeUTF8));
        tabWidget_2->setTabText(tabWidget_2->indexOf(tab_TestFont), QApplication::translate("FontBuilder", "Test font", 0, QApplication::UnicodeUTF8));
        menu_File->setTitle(QApplication::translate("FontBuilder", "&File", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class FontBuilder: public Ui_FontBuilder {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_FONTBUILDER_H
