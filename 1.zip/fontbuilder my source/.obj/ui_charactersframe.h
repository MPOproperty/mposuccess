/********************************************************************************
** Form generated from reading UI file 'charactersframe.ui'
**
** Created by: Qt User Interface Compiler version 4.8.6
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CHARACTERSFRAME_H
#define UI_CHARACTERSFRAME_H

#include <QtCore/QLocale>
#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QGridLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QPlainTextEdit>
#include <QtGui/QPushButton>
#include <QtGui/QVBoxLayout>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_CharactersFrame
{
public:
    QVBoxLayout *verticalLayout;
    QGridLayout *gridLayout;
    QPushButton *pushButtonImport;
    QPushButton *pushButtonExport;
    QPushButton *pushButton_SelectFromCharsMap;
    QPushButton *pushButtonDefault;
    QPlainTextEdit *plainTextEdit;
    QPushButton *pushButtonRefresh;

    void setupUi(QWidget *CharactersFrame)
    {
        if (CharactersFrame->objectName().isEmpty())
            CharactersFrame->setObjectName(QString::fromUtf8("CharactersFrame"));
        CharactersFrame->resize(303, 296);
        QSizePolicy sizePolicy(QSizePolicy::Minimum, QSizePolicy::Minimum);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(CharactersFrame->sizePolicy().hasHeightForWidth());
        CharactersFrame->setSizePolicy(sizePolicy);
        CharactersFrame->setLocale(QLocale(QLocale::English, QLocale::UnitedStates));
        verticalLayout = new QVBoxLayout(CharactersFrame);
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalLayout->setSizeConstraint(QLayout::SetMinimumSize);
        gridLayout = new QGridLayout();
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        pushButtonImport = new QPushButton(CharactersFrame);
        pushButtonImport->setObjectName(QString::fromUtf8("pushButtonImport"));

        gridLayout->addWidget(pushButtonImport, 0, 1, 1, 1);

        pushButtonExport = new QPushButton(CharactersFrame);
        pushButtonExport->setObjectName(QString::fromUtf8("pushButtonExport"));

        gridLayout->addWidget(pushButtonExport, 1, 1, 1, 1);

        pushButton_SelectFromCharsMap = new QPushButton(CharactersFrame);
        pushButton_SelectFromCharsMap->setObjectName(QString::fromUtf8("pushButton_SelectFromCharsMap"));
        pushButton_SelectFromCharsMap->setEnabled(true);

        gridLayout->addWidget(pushButton_SelectFromCharsMap, 0, 0, 1, 1);

        pushButtonDefault = new QPushButton(CharactersFrame);
        pushButtonDefault->setObjectName(QString::fromUtf8("pushButtonDefault"));

        gridLayout->addWidget(pushButtonDefault, 1, 0, 1, 1);


        verticalLayout->addLayout(gridLayout);

        plainTextEdit = new QPlainTextEdit(CharactersFrame);
        plainTextEdit->setObjectName(QString::fromUtf8("plainTextEdit"));

        verticalLayout->addWidget(plainTextEdit);

        pushButtonRefresh = new QPushButton(CharactersFrame);
        pushButtonRefresh->setObjectName(QString::fromUtf8("pushButtonRefresh"));

        verticalLayout->addWidget(pushButtonRefresh);


        retranslateUi(CharactersFrame);

        QMetaObject::connectSlotsByName(CharactersFrame);
    } // setupUi

    void retranslateUi(QWidget *CharactersFrame)
    {
        CharactersFrame->setWindowTitle(QApplication::translate("CharactersFrame", "Frame", 0, QApplication::UnicodeUTF8));
        pushButtonImport->setText(QApplication::translate("CharactersFrame", "Import from file ...", 0, QApplication::UnicodeUTF8));
        pushButtonExport->setText(QApplication::translate("CharactersFrame", "Export to file ...", 0, QApplication::UnicodeUTF8));
        pushButton_SelectFromCharsMap->setText(QApplication::translate("CharactersFrame", "Select from Chars Map", 0, QApplication::UnicodeUTF8));
        pushButtonDefault->setText(QApplication::translate("CharactersFrame", "Default", 0, QApplication::UnicodeUTF8));
        plainTextEdit->setPlainText(QString());
        pushButtonRefresh->setText(QApplication::translate("CharactersFrame", "Refresh", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class CharactersFrame: public Ui_CharactersFrame {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CHARACTERSFRAME_H
