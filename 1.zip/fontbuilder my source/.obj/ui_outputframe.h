/********************************************************************************
** Form generated from reading UI file 'outputframe.ui'
**
** Created by: Qt User Interface Compiler version 4.8.6
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_OUTPUTFRAME_H
#define UI_OUTPUTFRAME_H

#include <QtCore/QLocale>
#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QCheckBox>
#include <QtGui/QComboBox>
#include <QtGui/QGridLayout>
#include <QtGui/QGroupBox>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QPushButton>
#include <QtGui/QSpacerItem>
#include <QtGui/QWidget>
#include "colorbutton.h"

QT_BEGIN_NAMESPACE

class Ui_OutputFrame
{
public:
    QGridLayout *gridLayout;
    QLineEdit *lineEditPath;
    QLabel *label;
    QPushButton *pushButtonSelectPath;
    QGroupBox *groupBoxImage;
    QGridLayout *gridLayout_2;
    QLineEdit *lineEditImageFilename;
    QLabel *label_2;
    QComboBox *comboBoxImageFormat;
    QLabel *label_3;
    QComboBox *comboBoxImageChannels;
    QCheckBox *checkBoxDrawGrid;
    ColorButton *widgetGridColor;
    QGroupBox *groupBoxDescription;
    QGridLayout *gridLayout_3;
    QLineEdit *lineEditDescriptionFilename;
    QLabel *label_4;
    QLabel *label_5;
    QComboBox *comboBoxDescriptionType;
    QSpacerItem *verticalSpacer;

    void setupUi(QWidget *OutputFrame)
    {
        if (OutputFrame->objectName().isEmpty())
            OutputFrame->setObjectName(QString::fromUtf8("OutputFrame"));
        OutputFrame->resize(272, 330);
        QSizePolicy sizePolicy(QSizePolicy::Minimum, QSizePolicy::Minimum);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(OutputFrame->sizePolicy().hasHeightForWidth());
        OutputFrame->setSizePolicy(sizePolicy);
        OutputFrame->setLocale(QLocale(QLocale::English, QLocale::UnitedStates));
        gridLayout = new QGridLayout(OutputFrame);
        gridLayout->setContentsMargins(0, 0, 0, 0);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        gridLayout->setSizeConstraint(QLayout::SetMinimumSize);
        lineEditPath = new QLineEdit(OutputFrame);
        lineEditPath->setObjectName(QString::fromUtf8("lineEditPath"));
        lineEditPath->setReadOnly(true);

        gridLayout->addWidget(lineEditPath, 1, 0, 1, 1);

        label = new QLabel(OutputFrame);
        label->setObjectName(QString::fromUtf8("label"));

        gridLayout->addWidget(label, 0, 0, 1, 1);

        pushButtonSelectPath = new QPushButton(OutputFrame);
        pushButtonSelectPath->setObjectName(QString::fromUtf8("pushButtonSelectPath"));
        pushButtonSelectPath->setText(QString::fromUtf8("..."));

        gridLayout->addWidget(pushButtonSelectPath, 1, 1, 1, 1);

        groupBoxImage = new QGroupBox(OutputFrame);
        groupBoxImage->setObjectName(QString::fromUtf8("groupBoxImage"));
        groupBoxImage->setCheckable(true);
        gridLayout_2 = new QGridLayout(groupBoxImage);
        gridLayout_2->setObjectName(QString::fromUtf8("gridLayout_2"));
        lineEditImageFilename = new QLineEdit(groupBoxImage);
        lineEditImageFilename->setObjectName(QString::fromUtf8("lineEditImageFilename"));

        gridLayout_2->addWidget(lineEditImageFilename, 0, 1, 1, 2);

        label_2 = new QLabel(groupBoxImage);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        gridLayout_2->addWidget(label_2, 0, 0, 1, 1);

        comboBoxImageFormat = new QComboBox(groupBoxImage);
        comboBoxImageFormat->setObjectName(QString::fromUtf8("comboBoxImageFormat"));
        comboBoxImageFormat->setSizeAdjustPolicy(QComboBox::AdjustToMinimumContentsLengthWithIcon);
        comboBoxImageFormat->setFrame(true);

        gridLayout_2->addWidget(comboBoxImageFormat, 1, 1, 1, 1);

        label_3 = new QLabel(groupBoxImage);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        gridLayout_2->addWidget(label_3, 1, 0, 1, 1);

        comboBoxImageChannels = new QComboBox(groupBoxImage);
        comboBoxImageChannels->setObjectName(QString::fromUtf8("comboBoxImageChannels"));
        comboBoxImageChannels->setEnabled(false);

        gridLayout_2->addWidget(comboBoxImageChannels, 1, 2, 1, 1);

        checkBoxDrawGrid = new QCheckBox(groupBoxImage);
        checkBoxDrawGrid->setObjectName(QString::fromUtf8("checkBoxDrawGrid"));

        gridLayout_2->addWidget(checkBoxDrawGrid, 3, 1, 1, 1);

        widgetGridColor = new ColorButton(groupBoxImage);
        widgetGridColor->setObjectName(QString::fromUtf8("widgetGridColor"));
        widgetGridColor->setEnabled(false);

        gridLayout_2->addWidget(widgetGridColor, 3, 2, 1, 1);


        gridLayout->addWidget(groupBoxImage, 2, 0, 1, 2);

        groupBoxDescription = new QGroupBox(OutputFrame);
        groupBoxDescription->setObjectName(QString::fromUtf8("groupBoxDescription"));
        groupBoxDescription->setEnabled(true);
        groupBoxDescription->setCheckable(true);
        groupBoxDescription->setChecked(false);
        gridLayout_3 = new QGridLayout(groupBoxDescription);
        gridLayout_3->setObjectName(QString::fromUtf8("gridLayout_3"));
        lineEditDescriptionFilename = new QLineEdit(groupBoxDescription);
        lineEditDescriptionFilename->setObjectName(QString::fromUtf8("lineEditDescriptionFilename"));

        gridLayout_3->addWidget(lineEditDescriptionFilename, 0, 1, 1, 1);

        label_4 = new QLabel(groupBoxDescription);
        label_4->setObjectName(QString::fromUtf8("label_4"));

        gridLayout_3->addWidget(label_4, 0, 0, 1, 1);

        label_5 = new QLabel(groupBoxDescription);
        label_5->setObjectName(QString::fromUtf8("label_5"));

        gridLayout_3->addWidget(label_5, 1, 0, 1, 1);

        comboBoxDescriptionType = new QComboBox(groupBoxDescription);
        comboBoxDescriptionType->setObjectName(QString::fromUtf8("comboBoxDescriptionType"));

        gridLayout_3->addWidget(comboBoxDescriptionType, 1, 1, 1, 1);


        gridLayout->addWidget(groupBoxDescription, 3, 0, 1, 2);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout->addItem(verticalSpacer, 4, 0, 1, 1);

#ifndef QT_NO_SHORTCUT
        label->setBuddy(lineEditPath);
        label_2->setBuddy(lineEditImageFilename);
        label_3->setBuddy(comboBoxImageFormat);
#endif // QT_NO_SHORTCUT

        retranslateUi(OutputFrame);

        QMetaObject::connectSlotsByName(OutputFrame);
    } // setupUi

    void retranslateUi(QWidget *OutputFrame)
    {
        OutputFrame->setWindowTitle(QApplication::translate("OutputFrame", "Frame", 0, QApplication::UnicodeUTF8));
        lineEditPath->setText(QApplication::translate("OutputFrame", "./", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("OutputFrame", "Output directory:", 0, QApplication::UnicodeUTF8));
        groupBoxImage->setTitle(QApplication::translate("OutputFrame", "Image", 0, QApplication::UnicodeUTF8));
        label_2->setText(QApplication::translate("OutputFrame", "File name:", 0, QApplication::UnicodeUTF8));
        label_3->setText(QApplication::translate("OutputFrame", "Format:", 0, QApplication::UnicodeUTF8));
        checkBoxDrawGrid->setText(QApplication::translate("OutputFrame", "Write grid", 0, QApplication::UnicodeUTF8));
        groupBoxDescription->setTitle(QApplication::translate("OutputFrame", "Description", 0, QApplication::UnicodeUTF8));
        label_4->setText(QApplication::translate("OutputFrame", "File name:", 0, QApplication::UnicodeUTF8));
        label_5->setText(QApplication::translate("OutputFrame", "Format:", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class OutputFrame: public Ui_OutputFrame {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_OUTPUTFRAME_H
