/****************************************************************************
** Meta object code from reading C++ file 'fontconfig.h'
**
** Created by: The Qt Meta Object Compiler version 63 (Qt 4.8.6)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../src/fontconfig.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'fontconfig.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.6. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_FontConfig[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       7,   14, // methods
      17,   49, // properties
       1,  100, // enums/sets
       0,    0, // constructors
       0,       // flags
       7,       // signalCount

 // signals: signature, parameters, type, tag, flags
      12,   11,   11,   11, 0x05,
      26,   11,   11,   11, 0x05,
      40,   11,   11,   11, 0x05,
      59,   11,   11,   11, 0x05,
      73,   11,   11,   11, 0x05,
      93,   11,   11,   11, 0x05,
     119,   11,   11,   11, 0x05,

 // properties: name, type, flags
     144,  136, 0x0a095103,
     149,  136, 0x0a095103,
     158,  136, 0x0a095103,
     165,  136, 0x0a095103,
     175,  171, 0x02095103,
     185,  171, 0x02095103,
     190,  136, 0x0a095103,
     201,  171, 0x02095107,
     214,  209, 0x01095103,
     228,  209, 0x01095103,
     240,  171, 0x02095103,
     245,  171, 0x02095103,
     258,  252, 0x87095103,
     264,  252, 0x87095103,
     271,  171, 0x02095103,
     283,  171, 0x02095103,
     295,  171, 0x02095103,

 // enums: name, flags, count, data
     299, 0x0,    4,  104,

 // enum data: key, value
     313, uint(FontConfig::HintingDisable),
     328, uint(FontConfig::HintingDefault),
     343, uint(FontConfig::HintingForceFreetypeAuto),
     368, uint(FontConfig::HintingDisableFreetypeAuto),

       0        // eod
};

static const char qt_meta_stringdata_FontConfig[] = {
    "FontConfig\0\0nameChanged()\0fileChanged()\0"
    "faceIndexChanged()\0sizeChanged()\0"
    "charactersChanged()\0renderingOptionsChanged()\0"
    "spacingChanged()\0QString\0path\0filename\0"
    "family\0style\0int\0faceIndex\0size\0"
    "characters\0hinting\0bool\0renderMissing\0"
    "antialiased\0bold\0italic\0float\0width\0"
    "height\0lineSpacing\0charSpacing\0DPI\0"
    "HintingMethod\0HintingDisable\0"
    "HintingDefault\0HintingForceFreetypeAuto\0"
    "HintingDisableFreetypeAuto\0"
};

void FontConfig::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        FontConfig *_t = static_cast<FontConfig *>(_o);
        switch (_id) {
        case 0: _t->nameChanged(); break;
        case 1: _t->fileChanged(); break;
        case 2: _t->faceIndexChanged(); break;
        case 3: _t->sizeChanged(); break;
        case 4: _t->charactersChanged(); break;
        case 5: _t->renderingOptionsChanged(); break;
        case 6: _t->spacingChanged(); break;
        default: ;
        }
    }
    Q_UNUSED(_a);
}

const QMetaObjectExtraData FontConfig::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject FontConfig::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_FontConfig,
      qt_meta_data_FontConfig, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &FontConfig::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *FontConfig::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *FontConfig::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_FontConfig))
        return static_cast<void*>(const_cast< FontConfig*>(this));
    return QObject::qt_metacast(_clname);
}

int FontConfig::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 7)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 7;
    }
#ifndef QT_NO_PROPERTIES
      else if (_c == QMetaObject::ReadProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< QString*>(_v) = path(); break;
        case 1: *reinterpret_cast< QString*>(_v) = filename(); break;
        case 2: *reinterpret_cast< QString*>(_v) = family(); break;
        case 3: *reinterpret_cast< QString*>(_v) = style(); break;
        case 4: *reinterpret_cast< int*>(_v) = faceIndex(); break;
        case 5: *reinterpret_cast< int*>(_v) = size(); break;
        case 6: *reinterpret_cast< QString*>(_v) = characters(); break;
        case 7: *reinterpret_cast< int*>(_v) = hinting(); break;
        case 8: *reinterpret_cast< bool*>(_v) = renderMissing(); break;
        case 9: *reinterpret_cast< bool*>(_v) = antialiased(); break;
        case 10: *reinterpret_cast< int*>(_v) = bold(); break;
        case 11: *reinterpret_cast< int*>(_v) = italic(); break;
        case 12: *reinterpret_cast< float*>(_v) = width(); break;
        case 13: *reinterpret_cast< float*>(_v) = height(); break;
        case 14: *reinterpret_cast< int*>(_v) = lineSpacing(); break;
        case 15: *reinterpret_cast< int*>(_v) = charSpacing(); break;
        case 16: *reinterpret_cast< int*>(_v) = DPI(); break;
        }
        _id -= 17;
    } else if (_c == QMetaObject::WriteProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: setPath(*reinterpret_cast< QString*>(_v)); break;
        case 1: setFilename(*reinterpret_cast< QString*>(_v)); break;
        case 2: setFamily(*reinterpret_cast< QString*>(_v)); break;
        case 3: setStyle(*reinterpret_cast< QString*>(_v)); break;
        case 4: setFaceIndex(*reinterpret_cast< int*>(_v)); break;
        case 5: setSize(*reinterpret_cast< int*>(_v)); break;
        case 6: setCharacters(*reinterpret_cast< QString*>(_v)); break;
        case 7: setHinting(*reinterpret_cast< int*>(_v)); break;
        case 8: setRenderMissing(*reinterpret_cast< bool*>(_v)); break;
        case 9: setAntialiased(*reinterpret_cast< bool*>(_v)); break;
        case 10: setBold(*reinterpret_cast< int*>(_v)); break;
        case 11: setItalic(*reinterpret_cast< int*>(_v)); break;
        case 12: setWidth(*reinterpret_cast< float*>(_v)); break;
        case 13: setHeight(*reinterpret_cast< float*>(_v)); break;
        case 14: setLineSpacing(*reinterpret_cast< int*>(_v)); break;
        case 15: setCharSpacing(*reinterpret_cast< int*>(_v)); break;
        case 16: setDPI(*reinterpret_cast< int*>(_v)); break;
        }
        _id -= 17;
    } else if (_c == QMetaObject::ResetProperty) {
        switch (_id) {
        case 7: resetHinting(); break;
        }
        _id -= 17;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 17;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 17;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 17;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 17;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 17;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}

// SIGNAL 0
void FontConfig::nameChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 0, 0);
}

// SIGNAL 1
void FontConfig::fileChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 1, 0);
}

// SIGNAL 2
void FontConfig::faceIndexChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 2, 0);
}

// SIGNAL 3
void FontConfig::sizeChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 3, 0);
}

// SIGNAL 4
void FontConfig::charactersChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 4, 0);
}

// SIGNAL 5
void FontConfig::renderingOptionsChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 5, 0);
}

// SIGNAL 6
void FontConfig::spacingChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 6, 0);
}
QT_END_MOC_NAMESPACE
