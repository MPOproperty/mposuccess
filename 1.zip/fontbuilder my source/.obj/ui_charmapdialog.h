/********************************************************************************
** Form generated from reading UI file 'charmapdialog.ui'
**
** Created by: Qt User Interface Compiler version 4.8.6
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CHARMAPDIALOG_H
#define UI_CHARMAPDIALOG_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDialog>
#include <QtGui/QDialogButtonBox>
#include <QtGui/QGridLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QListWidget>
#include <QtGui/QScrollArea>
#include <QtGui/QWidget>
#include "charsselectwidget.h"

QT_BEGIN_NAMESPACE

class Ui_CharMapDialog
{
public:
    QGridLayout *gridLayout_2;
    QListWidget *listWidget;
    QScrollArea *scrollArea;
    QWidget *scrollAreaWidgetContents;
    QGridLayout *gridLayout;
    CharsSelectWidget *widget;
    QDialogButtonBox *buttonBox;

    void setupUi(QDialog *CharMapDialog)
    {
        if (CharMapDialog->objectName().isEmpty())
            CharMapDialog->setObjectName(QString::fromUtf8("CharMapDialog"));
        CharMapDialog->resize(747, 389);
        CharMapDialog->setModal(true);
        gridLayout_2 = new QGridLayout(CharMapDialog);
        gridLayout_2->setObjectName(QString::fromUtf8("gridLayout_2"));
        listWidget = new QListWidget(CharMapDialog);
        listWidget->setObjectName(QString::fromUtf8("listWidget"));

        gridLayout_2->addWidget(listWidget, 0, 0, 1, 1);

        scrollArea = new QScrollArea(CharMapDialog);
        scrollArea->setObjectName(QString::fromUtf8("scrollArea"));
        scrollArea->setWidgetResizable(true);
        scrollAreaWidgetContents = new QWidget();
        scrollAreaWidgetContents->setObjectName(QString::fromUtf8("scrollAreaWidgetContents"));
        scrollAreaWidgetContents->setGeometry(QRect(0, 0, 463, 330));
        gridLayout = new QGridLayout(scrollAreaWidgetContents);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        widget = new CharsSelectWidget(scrollAreaWidgetContents);
        widget->setObjectName(QString::fromUtf8("widget"));
        QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(widget->sizePolicy().hasHeightForWidth());
        widget->setSizePolicy(sizePolicy);

        gridLayout->addWidget(widget, 0, 0, 1, 1);

        scrollArea->setWidget(scrollAreaWidgetContents);

        gridLayout_2->addWidget(scrollArea, 0, 1, 1, 1);

        buttonBox = new QDialogButtonBox(CharMapDialog);
        buttonBox->setObjectName(QString::fromUtf8("buttonBox"));
        buttonBox->setOrientation(Qt::Horizontal);
        buttonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);

        gridLayout_2->addWidget(buttonBox, 1, 0, 1, 2);

        gridLayout_2->setColumnStretch(1, 1);

        retranslateUi(CharMapDialog);
        QObject::connect(buttonBox, SIGNAL(accepted()), CharMapDialog, SLOT(accept()));
        QObject::connect(buttonBox, SIGNAL(rejected()), CharMapDialog, SLOT(reject()));

        QMetaObject::connectSlotsByName(CharMapDialog);
    } // setupUi

    void retranslateUi(QDialog *CharMapDialog)
    {
        CharMapDialog->setWindowTitle(QApplication::translate("CharMapDialog", "Chars map", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class CharMapDialog: public Ui_CharMapDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CHARMAPDIALOG_H
