/********************************************************************************
** Form generated from reading UI file 'layoutconfigframe.ui'
**
** Created by: Qt User Interface Compiler version 4.8.6
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_LAYOUTCONFIGFRAME_H
#define UI_LAYOUTCONFIGFRAME_H

#include <QtCore/QLocale>
#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QCheckBox>
#include <QtGui/QGridLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QSpinBox>
#include <QtGui/QVBoxLayout>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_LayoutConfigFrame
{
public:
    QVBoxLayout *verticalLayout;
    QCheckBox *checkBoxOnePixelOffset;
    QCheckBox *checkBoxPOT;
    QLabel *label_3;
    QSpinBox *spinBoxoffsetTOP;
    QLabel *label_2;
    QSpinBox *spinBoxSizeIncrement;
    QGridLayout *gridLayout;
    QSpinBox *spinBoxRightOffset;
    QSpinBox *spinBoxLeftOffset;
    QLabel *label;
    QSpinBox *spinBoxTopOffset;
    QSpinBox *spinBoxBottomOffset;

    void setupUi(QWidget *LayoutConfigFrame)
    {
        if (LayoutConfigFrame->objectName().isEmpty())
            LayoutConfigFrame->setObjectName(QString::fromUtf8("LayoutConfigFrame"));
        LayoutConfigFrame->resize(197, 207);
        QSizePolicy sizePolicy(QSizePolicy::Minimum, QSizePolicy::Minimum);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(LayoutConfigFrame->sizePolicy().hasHeightForWidth());
        LayoutConfigFrame->setSizePolicy(sizePolicy);
        LayoutConfigFrame->setLocale(QLocale(QLocale::English, QLocale::UnitedStates));
        verticalLayout = new QVBoxLayout(LayoutConfigFrame);
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalLayout->setSizeConstraint(QLayout::SetMinimumSize);
        checkBoxOnePixelOffset = new QCheckBox(LayoutConfigFrame);
        checkBoxOnePixelOffset->setObjectName(QString::fromUtf8("checkBoxOnePixelOffset"));

        verticalLayout->addWidget(checkBoxOnePixelOffset);

        checkBoxPOT = new QCheckBox(LayoutConfigFrame);
        checkBoxPOT->setObjectName(QString::fromUtf8("checkBoxPOT"));

        verticalLayout->addWidget(checkBoxPOT);

        label_3 = new QLabel(LayoutConfigFrame);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        verticalLayout->addWidget(label_3);

        spinBoxoffsetTOP = new QSpinBox(LayoutConfigFrame);
        spinBoxoffsetTOP->setObjectName(QString::fromUtf8("spinBoxoffsetTOP"));
        spinBoxoffsetTOP->setValue(1);

        verticalLayout->addWidget(spinBoxoffsetTOP);

        label_2 = new QLabel(LayoutConfigFrame);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        verticalLayout->addWidget(label_2);

        spinBoxSizeIncrement = new QSpinBox(LayoutConfigFrame);
        spinBoxSizeIncrement->setObjectName(QString::fromUtf8("spinBoxSizeIncrement"));
        spinBoxSizeIncrement->setMinimum(1);
        spinBoxSizeIncrement->setMaximum(1048576);

        verticalLayout->addWidget(spinBoxSizeIncrement);

        gridLayout = new QGridLayout();
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        spinBoxRightOffset = new QSpinBox(LayoutConfigFrame);
        spinBoxRightOffset->setObjectName(QString::fromUtf8("spinBoxRightOffset"));
        spinBoxRightOffset->setMaximum(20);

        gridLayout->addWidget(spinBoxRightOffset, 1, 2, 1, 1);

        spinBoxLeftOffset = new QSpinBox(LayoutConfigFrame);
        spinBoxLeftOffset->setObjectName(QString::fromUtf8("spinBoxLeftOffset"));
        spinBoxLeftOffset->setMaximum(20);

        gridLayout->addWidget(spinBoxLeftOffset, 1, 0, 1, 1);

        label = new QLabel(LayoutConfigFrame);
        label->setObjectName(QString::fromUtf8("label"));
        label->setAlignment(Qt::AlignCenter);

        gridLayout->addWidget(label, 1, 1, 1, 1);

        spinBoxTopOffset = new QSpinBox(LayoutConfigFrame);
        spinBoxTopOffset->setObjectName(QString::fromUtf8("spinBoxTopOffset"));
        spinBoxTopOffset->setMaximum(20);

        gridLayout->addWidget(spinBoxTopOffset, 0, 1, 1, 1);

        spinBoxBottomOffset = new QSpinBox(LayoutConfigFrame);
        spinBoxBottomOffset->setObjectName(QString::fromUtf8("spinBoxBottomOffset"));
        spinBoxBottomOffset->setMaximum(20);

        gridLayout->addWidget(spinBoxBottomOffset, 2, 1, 1, 1);


        verticalLayout->addLayout(gridLayout);

#ifndef QT_NO_SHORTCUT
        label_2->setBuddy(spinBoxSizeIncrement);
#endif // QT_NO_SHORTCUT

        retranslateUi(LayoutConfigFrame);

        QMetaObject::connectSlotsByName(LayoutConfigFrame);
    } // setupUi

    void retranslateUi(QWidget *LayoutConfigFrame)
    {
        LayoutConfigFrame->setWindowTitle(QApplication::translate("LayoutConfigFrame", "Frame", 0, QApplication::UnicodeUTF8));
        checkBoxOnePixelOffset->setText(QApplication::translate("LayoutConfigFrame", "One pixel separator", 0, QApplication::UnicodeUTF8));
        checkBoxPOT->setText(QApplication::translate("LayoutConfigFrame", "Power of two image", 0, QApplication::UnicodeUTF8));
        label_3->setText(QApplication::translate("LayoutConfigFrame", "Character offset to the top:", 0, QApplication::UnicodeUTF8));
        label_2->setText(QApplication::translate("LayoutConfigFrame", "Round size to a multiple of:", 0, QApplication::UnicodeUTF8));
        spinBoxSizeIncrement->setSuffix(QApplication::translate("LayoutConfigFrame", " pixels", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("LayoutConfigFrame", "Padding", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class LayoutConfigFrame: public Ui_LayoutConfigFrame {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_LAYOUTCONFIGFRAME_H
