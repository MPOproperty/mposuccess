/****************************************************************************
** Meta object code from reading C++ file 'outputconfig.h'
**
** Created by: The Qt Meta Object Compiler version 63 (Qt 4.8.6)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../src/outputconfig.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'outputconfig.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.6. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_OutputConfig[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       2,   14, // methods
       7,   24, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       2,       // signalCount

 // signals: signature, parameters, type, tag, flags
      14,   13,   13,   13, 0x05,
      40,   13,   13,   13, 0x05,

 // properties: name, type, flags
      80,   72, 0x0a095103,
      85,   72, 0x0a095103,
      95,   72, 0x0a095103,
     107,   72, 0x0a095103,
     123,   72, 0x0a095103,
     146,  141, 0x01095103,
     157,  141, 0x01095103,

       0        // eod
};

static const char qt_meta_stringdata_OutputConfig[] = {
    "OutputConfig\0\0imageNameChanged(QString)\0"
    "descriptionNameChanged(QString)\0QString\0"
    "path\0imageName\0imageFormat\0descriptionName\0"
    "descriptionFormat\0bool\0writeImage\0"
    "writeDescription\0"
};

void OutputConfig::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        OutputConfig *_t = static_cast<OutputConfig *>(_o);
        switch (_id) {
        case 0: _t->imageNameChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 1: _t->descriptionNameChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData OutputConfig::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject OutputConfig::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_OutputConfig,
      qt_meta_data_OutputConfig, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &OutputConfig::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *OutputConfig::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *OutputConfig::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_OutputConfig))
        return static_cast<void*>(const_cast< OutputConfig*>(this));
    return QObject::qt_metacast(_clname);
}

int OutputConfig::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 2)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 2;
    }
#ifndef QT_NO_PROPERTIES
      else if (_c == QMetaObject::ReadProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< QString*>(_v) = path(); break;
        case 1: *reinterpret_cast< QString*>(_v) = imageName(); break;
        case 2: *reinterpret_cast< QString*>(_v) = imageFormat(); break;
        case 3: *reinterpret_cast< QString*>(_v) = descriptionName(); break;
        case 4: *reinterpret_cast< QString*>(_v) = descriptionFormat(); break;
        case 5: *reinterpret_cast< bool*>(_v) = writeImage(); break;
        case 6: *reinterpret_cast< bool*>(_v) = writeDescription(); break;
        }
        _id -= 7;
    } else if (_c == QMetaObject::WriteProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: setPath(*reinterpret_cast< QString*>(_v)); break;
        case 1: setImageName(*reinterpret_cast< QString*>(_v)); break;
        case 2: setImageFormat(*reinterpret_cast< QString*>(_v)); break;
        case 3: setDescriptionName(*reinterpret_cast< QString*>(_v)); break;
        case 4: setDescriptionFormat(*reinterpret_cast< QString*>(_v)); break;
        case 5: setWriteImage(*reinterpret_cast< bool*>(_v)); break;
        case 6: setWriteDescription(*reinterpret_cast< bool*>(_v)); break;
        }
        _id -= 7;
    } else if (_c == QMetaObject::ResetProperty) {
        _id -= 7;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 7;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 7;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 7;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 7;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 7;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}

// SIGNAL 0
void OutputConfig::imageNameChanged(const QString & _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void OutputConfig::descriptionNameChanged(const QString & _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}
QT_END_MOC_NAMESPACE
