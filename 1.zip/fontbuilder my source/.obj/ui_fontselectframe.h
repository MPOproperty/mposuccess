/********************************************************************************
** Form generated from reading UI file 'fontselectframe.ui'
**
** Created by: Qt User Interface Compiler version 4.8.6
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_FONTSELECTFRAME_H
#define UI_FONTSELECTFRAME_H

#include <QtCore/QLocale>
#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QComboBox>
#include <QtGui/QGridLayout>
#include <QtGui/QHBoxLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QPushButton>
#include <QtGui/QVBoxLayout>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_FontSelectFrame
{
public:
    QVBoxLayout *verticalLayout;
    QLabel *label;
    QHBoxLayout *horizontalLayout;
    QLineEdit *lineEditFontsDir;
    QPushButton *pushButtonChangeDir;
    QPushButton *pushButtonDefault;
    QGridLayout *gridLayout;
    QLabel *label_Family;
    QLabel *label_Style;
    QLabel *label_4;
    QComboBox *comboBoxFamily;
    QComboBox *comboBoxStyle;
    QComboBox *comboBoxSize;
    QLabel *label_FileName;

    void setupUi(QWidget *FontSelectFrame)
    {
        if (FontSelectFrame->objectName().isEmpty())
            FontSelectFrame->setObjectName(QString::fromUtf8("FontSelectFrame"));
        FontSelectFrame->resize(342, 143);
        QSizePolicy sizePolicy(QSizePolicy::Minimum, QSizePolicy::Minimum);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(FontSelectFrame->sizePolicy().hasHeightForWidth());
        FontSelectFrame->setSizePolicy(sizePolicy);
        FontSelectFrame->setLocale(QLocale(QLocale::English, QLocale::UnitedStates));
        verticalLayout = new QVBoxLayout(FontSelectFrame);
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalLayout->setSizeConstraint(QLayout::SetMinimumSize);
        label = new QLabel(FontSelectFrame);
        label->setObjectName(QString::fromUtf8("label"));

        verticalLayout->addWidget(label);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        lineEditFontsDir = new QLineEdit(FontSelectFrame);
        lineEditFontsDir->setObjectName(QString::fromUtf8("lineEditFontsDir"));
        lineEditFontsDir->setEnabled(true);
        lineEditFontsDir->setReadOnly(true);

        horizontalLayout->addWidget(lineEditFontsDir);

        pushButtonChangeDir = new QPushButton(FontSelectFrame);
        pushButtonChangeDir->setObjectName(QString::fromUtf8("pushButtonChangeDir"));

        horizontalLayout->addWidget(pushButtonChangeDir);

        pushButtonDefault = new QPushButton(FontSelectFrame);
        pushButtonDefault->setObjectName(QString::fromUtf8("pushButtonDefault"));

        horizontalLayout->addWidget(pushButtonDefault);

        horizontalLayout->setStretch(0, 1);

        verticalLayout->addLayout(horizontalLayout);

        gridLayout = new QGridLayout();
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        label_Family = new QLabel(FontSelectFrame);
        label_Family->setObjectName(QString::fromUtf8("label_Family"));

        gridLayout->addWidget(label_Family, 1, 0, 1, 1);

        label_Style = new QLabel(FontSelectFrame);
        label_Style->setObjectName(QString::fromUtf8("label_Style"));

        gridLayout->addWidget(label_Style, 1, 1, 1, 1);

        label_4 = new QLabel(FontSelectFrame);
        label_4->setObjectName(QString::fromUtf8("label_4"));

        gridLayout->addWidget(label_4, 1, 2, 1, 1);

        comboBoxFamily = new QComboBox(FontSelectFrame);
        comboBoxFamily->setObjectName(QString::fromUtf8("comboBoxFamily"));
        comboBoxFamily->setInsertPolicy(QComboBox::InsertAlphabetically);

        gridLayout->addWidget(comboBoxFamily, 2, 0, 1, 1);

        comboBoxStyle = new QComboBox(FontSelectFrame);
        comboBoxStyle->setObjectName(QString::fromUtf8("comboBoxStyle"));
        comboBoxStyle->setDuplicatesEnabled(true);

        gridLayout->addWidget(comboBoxStyle, 2, 1, 1, 1);

        comboBoxSize = new QComboBox(FontSelectFrame);
        comboBoxSize->setObjectName(QString::fromUtf8("comboBoxSize"));
        comboBoxSize->setEditable(true);
        comboBoxSize->setInsertPolicy(QComboBox::InsertAlphabetically);

        gridLayout->addWidget(comboBoxSize, 2, 2, 1, 1);

        gridLayout->setColumnStretch(0, 2);
        gridLayout->setColumnStretch(1, 1);
        gridLayout->setColumnMinimumWidth(2, 1);

        verticalLayout->addLayout(gridLayout);

        label_FileName = new QLabel(FontSelectFrame);
        label_FileName->setObjectName(QString::fromUtf8("label_FileName"));

        verticalLayout->addWidget(label_FileName);

#ifndef QT_NO_SHORTCUT
        label->setBuddy(lineEditFontsDir);
        label_Family->setBuddy(comboBoxFamily);
        label_Style->setBuddy(comboBoxStyle);
        label_4->setBuddy(comboBoxSize);
#endif // QT_NO_SHORTCUT
        QWidget::setTabOrder(pushButtonChangeDir, lineEditFontsDir);
        QWidget::setTabOrder(lineEditFontsDir, comboBoxFamily);
        QWidget::setTabOrder(comboBoxFamily, comboBoxStyle);
        QWidget::setTabOrder(comboBoxStyle, comboBoxSize);

        retranslateUi(FontSelectFrame);

        QMetaObject::connectSlotsByName(FontSelectFrame);
    } // setupUi

    void retranslateUi(QWidget *FontSelectFrame)
    {
        FontSelectFrame->setWindowTitle(QApplication::translate("FontSelectFrame", "Frame", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("FontSelectFrame", "Fonts directory:", 0, QApplication::UnicodeUTF8));
        pushButtonChangeDir->setText(QApplication::translate("FontSelectFrame", "...", 0, QApplication::UnicodeUTF8));
        pushButtonDefault->setText(QApplication::translate("FontSelectFrame", "Default", 0, QApplication::UnicodeUTF8));
        label_Family->setText(QApplication::translate("FontSelectFrame", "Family", 0, QApplication::UnicodeUTF8));
        label_Style->setText(QApplication::translate("FontSelectFrame", "Style", 0, QApplication::UnicodeUTF8));
        label_4->setText(QApplication::translate("FontSelectFrame", "Size", 0, QApplication::UnicodeUTF8));
        label_FileName->setText(QApplication::translate("FontSelectFrame", "File:", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class FontSelectFrame: public Ui_FontSelectFrame {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_FONTSELECTFRAME_H
