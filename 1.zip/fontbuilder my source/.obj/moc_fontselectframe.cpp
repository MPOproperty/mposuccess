/****************************************************************************
** Meta object code from reading C++ file 'fontselectframe.h'
**
** Created by: The Qt Meta Object Compiler version 63 (Qt 4.8.6)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../src/fontselectframe.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'fontselectframe.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.6. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_FontSelectFrame[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       8,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      17,   16,   16,   16, 0x08,
      48,   16,   16,   16, 0x08,
      93,   16,   16,   16, 0x08,
     140,  134,   16,   16, 0x08,
     182,   16,   16,   16, 0x08,
     229,   16,   16,   16, 0x08,
     266,  262,   16,   16, 0x08,
     293,   16,   16,   16, 0x08,

       0        // eod
};

static const char qt_meta_stringdata_FontSelectFrame[] = {
    "FontSelectFrame\0\0on_pushButtonDefault_clicked()\0"
    "on_comboBoxSize_currentIndexChanged(QString)\0"
    "on_comboBoxSize_editTextChanged(QString)\0"
    "index\0on_comboBoxStyle_currentIndexChanged(int)\0"
    "on_comboBoxFamily_currentIndexChanged(QString)\0"
    "on_pushButtonChangeDir_clicked()\0dir\0"
    "setFontsDirectory(QString)\0"
    "on_pushButtonDefault_pressed()\0"
};

void FontSelectFrame::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        FontSelectFrame *_t = static_cast<FontSelectFrame *>(_o);
        switch (_id) {
        case 0: _t->on_pushButtonDefault_clicked(); break;
        case 1: _t->on_comboBoxSize_currentIndexChanged((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 2: _t->on_comboBoxSize_editTextChanged((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 3: _t->on_comboBoxStyle_currentIndexChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 4: _t->on_comboBoxFamily_currentIndexChanged((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 5: _t->on_pushButtonChangeDir_clicked(); break;
        case 6: _t->setFontsDirectory((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 7: _t->on_pushButtonDefault_pressed(); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData FontSelectFrame::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject FontSelectFrame::staticMetaObject = {
    { &QFrame::staticMetaObject, qt_meta_stringdata_FontSelectFrame,
      qt_meta_data_FontSelectFrame, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &FontSelectFrame::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *FontSelectFrame::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *FontSelectFrame::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_FontSelectFrame))
        return static_cast<void*>(const_cast< FontSelectFrame*>(this));
    return QFrame::qt_metacast(_clname);
}

int FontSelectFrame::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QFrame::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 8)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 8;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
