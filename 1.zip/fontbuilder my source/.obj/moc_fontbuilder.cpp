/****************************************************************************
** Meta object code from reading C++ file 'fontbuilder.h'
**
** Created by: The Qt Meta Object Compiler version 63 (Qt 4.8.6)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../src/fontbuilder.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'fontbuilder.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.6. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_FontBuilder[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
      11,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      13,   12,   12,   12, 0x0a,
      37,   12,   12,   12, 0x08,
      70,   12,   12,   12, 0x08,
     119,   12,   12,   12, 0x08,
     153,   12,   12,   12, 0x08,
     171,   12,   12,   12, 0x08,
     191,   12,   12,   12, 0x08,
     215,  211,   12,   12, 0x08,
     247,   12,   12,   12, 0x08,
     272,  266,   12,   12, 0x08,
     309,   12,   12,   12, 0x08,

       0        // eod
};

static const char qt_meta_stringdata_FontBuilder[] = {
    "FontBuilder\0\0fontParametersChanged()\0"
    "on_pushButtonWriteFont_clicked()\0"
    "on_comboBoxLayouter_currentIndexChanged(QString)\0"
    "on_checkBoxDrawGrid_toggled(bool)\0"
    "onLayoutChanged()\0onRenderedChanged()\0"
    "onFontNameChanged()\0img\0"
    "onExternalImageChanged(QString)\0"
    "onSpacingChanged()\0index\0"
    "on_comboBox_currentIndexChanged(int)\0"
    "on_action_Open_triggered()\0"
};

void FontBuilder::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        FontBuilder *_t = static_cast<FontBuilder *>(_o);
        switch (_id) {
        case 0: _t->fontParametersChanged(); break;
        case 1: _t->on_pushButtonWriteFont_clicked(); break;
        case 2: _t->on_comboBoxLayouter_currentIndexChanged((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 3: _t->on_checkBoxDrawGrid_toggled((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 4: _t->onLayoutChanged(); break;
        case 5: _t->onRenderedChanged(); break;
        case 6: _t->onFontNameChanged(); break;
        case 7: _t->onExternalImageChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 8: _t->onSpacingChanged(); break;
        case 9: _t->on_comboBox_currentIndexChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 10: _t->on_action_Open_triggered(); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData FontBuilder::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject FontBuilder::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_FontBuilder,
      qt_meta_data_FontBuilder, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &FontBuilder::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *FontBuilder::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *FontBuilder::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_FontBuilder))
        return static_cast<void*>(const_cast< FontBuilder*>(this));
    return QMainWindow::qt_metacast(_clname);
}

int FontBuilder::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 11)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 11;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
