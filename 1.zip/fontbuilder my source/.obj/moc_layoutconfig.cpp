/****************************************************************************
** Meta object code from reading C++ file 'layoutconfig.h'
**
** Created by: The Qt Meta Object Compiler version 63 (Qt 4.8.6)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../src/layoutconfig.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'layoutconfig.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.6. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_LayoutConfig[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       1,   14, // methods
       8,   19, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       1,       // signalCount

 // signals: signature, parameters, type, tag, flags
      14,   13,   13,   13, 0x05,

 // properties: name, type, flags
      41,   36, 0x01095103,
      56,   36, 0x01095103,
      69,   65, 0x02095103,
      83,   65, 0x02095103,
      94,   65, 0x02095103,
     104,   65, 0x02095103,
     116,   65, 0x02095103,
     137,  129, 0x0a095103,

       0        // eod
};

static const char qt_meta_stringdata_LayoutConfig[] = {
    "LayoutConfig\0\0layoutConfigChanged()\0"
    "bool\0onePixelOffset\0potImage\0int\0"
    "sizeIncrement\0offsetLeft\0offsetTop\0"
    "offsetRight\0offsetBottom\0QString\0"
    "layouter\0"
};

void LayoutConfig::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        LayoutConfig *_t = static_cast<LayoutConfig *>(_o);
        switch (_id) {
        case 0: _t->layoutConfigChanged(); break;
        default: ;
        }
    }
    Q_UNUSED(_a);
}

const QMetaObjectExtraData LayoutConfig::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject LayoutConfig::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_LayoutConfig,
      qt_meta_data_LayoutConfig, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &LayoutConfig::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *LayoutConfig::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *LayoutConfig::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_LayoutConfig))
        return static_cast<void*>(const_cast< LayoutConfig*>(this));
    return QObject::qt_metacast(_clname);
}

int LayoutConfig::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 1)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 1;
    }
#ifndef QT_NO_PROPERTIES
      else if (_c == QMetaObject::ReadProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< bool*>(_v) = onePixelOffset(); break;
        case 1: *reinterpret_cast< bool*>(_v) = potImage(); break;
        case 2: *reinterpret_cast< int*>(_v) = sizeIncrement(); break;
        case 3: *reinterpret_cast< int*>(_v) = offsetLeft(); break;
        case 4: *reinterpret_cast< int*>(_v) = offsetTop(); break;
        case 5: *reinterpret_cast< int*>(_v) = offsetRight(); break;
        case 6: *reinterpret_cast< int*>(_v) = offsetBottom(); break;
        case 7: *reinterpret_cast< QString*>(_v) = layouter(); break;
        }
        _id -= 8;
    } else if (_c == QMetaObject::WriteProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: setOnePixelOffset(*reinterpret_cast< bool*>(_v)); break;
        case 1: setPotImage(*reinterpret_cast< bool*>(_v)); break;
        case 2: setSizeIncrement(*reinterpret_cast< int*>(_v)); break;
        case 3: setOffsetLeft(*reinterpret_cast< int*>(_v)); break;
        case 4: setOffsetTop(*reinterpret_cast< int*>(_v)); break;
        case 5: setOffsetRight(*reinterpret_cast< int*>(_v)); break;
        case 6: setOffsetBottom(*reinterpret_cast< int*>(_v)); break;
        case 7: setLayouter(*reinterpret_cast< QString*>(_v)); break;
        }
        _id -= 8;
    } else if (_c == QMetaObject::ResetProperty) {
        _id -= 8;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 8;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 8;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 8;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 8;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 8;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}

// SIGNAL 0
void LayoutConfig::layoutConfigChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 0, 0);
}
QT_END_MOC_NAMESPACE
