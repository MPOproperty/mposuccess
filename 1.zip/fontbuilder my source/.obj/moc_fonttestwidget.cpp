/****************************************************************************
** Meta object code from reading C++ file 'fonttestwidget.h'
**
** Created by: The Qt Meta Object Compiler version 63 (Qt 4.8.6)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../src/fonttestwidget.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'fonttestwidget.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.6. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_FontTestWidget[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       2,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      16,   15,   15,   15, 0x0a,
      28,   26,   15,   15, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_FontTestWidget[] = {
    "FontTestWidget\0\0refresh()\0c\0"
    "setBGColor(QColor)\0"
};

void FontTestWidget::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        FontTestWidget *_t = static_cast<FontTestWidget *>(_o);
        switch (_id) {
        case 0: _t->refresh(); break;
        case 1: _t->setBGColor((*reinterpret_cast< QColor(*)>(_a[1]))); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData FontTestWidget::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject FontTestWidget::staticMetaObject = {
    { &QWidget::staticMetaObject, qt_meta_stringdata_FontTestWidget,
      qt_meta_data_FontTestWidget, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &FontTestWidget::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *FontTestWidget::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *FontTestWidget::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_FontTestWidget))
        return static_cast<void*>(const_cast< FontTestWidget*>(this));
    return QWidget::qt_metacast(_clname);
}

int FontTestWidget::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 2)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 2;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
